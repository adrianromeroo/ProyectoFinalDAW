package dao;

public interface LoginDAO {
	public boolean doLogin(String username, String password);
	public boolean checkPassword (String password, String hashedPassword);
}
