package dao;

import java.util.List;
import model.User;

public interface UserDAO {
	public List<User> getUsers();
	public boolean checkUsername(String username);
	public boolean createUser(String name, String surname, String username, int age, String password);
}
