package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import database.DBConnection;
import model.User;

public class UserDAOImpl implements UserDAO{
	
	final static Logger logger = Logger.getLogger(UserDAOImpl.class);
	
	public List<User> getUsers() {
		
		logger.info("getUSers method has been invoked [UserDAOImpl.class]");
			
		List<User> users = null;
		Connection con = DBConnection.getConnecttion();
		
		if(con != null) {
			String sql = "select id,name,surname,username,age,password,role from user;";
			PreparedStatement ps;
			
			users = new ArrayList<User>();
			
			try {
				ps = (PreparedStatement) con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				
				while (rs.next()) {
					try {
						users.add(new User(rs.getInt("id"), rs.getString("name"), rs.getString("surname"),rs.getString("username"), rs.getInt("age"), rs.getString("password"), rs.getString("role")));								
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				con.close();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.info("getUsers method has retrieved "+(users.isEmpty()?"nothing":String.valueOf(users.size()))+" [UsersDAOImpl.class]");
		return users;
		
	}

	@Override
	public boolean checkUsername(String username) {
		
		boolean result = false;
		
		Connection con = DBConnection.getConnecttion();
		
		if (con != null) {
			String sql = "select username from user where username = ?;";
			try  {
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1,username);
				ResultSet rs = ps.executeQuery();
				
				if (rs.next()) {
					result = true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return result;
	}

	@Override
	public boolean createUser(String name, String surname, String username, int age, String password) {
		
		boolean result = false;
		
		Connection con = DBConnection.getConnecttion();

		if(con != null) {
		
			String sql = "insert into user (name,surname,username,age,password,role) values (?, ?, ?, ?, ?, ?);";
			
			PreparedStatement ps;
			
			try {
				
				ps = (PreparedStatement) con.prepareStatement(sql);
				
				ps.setString(1, name);
				ps.setString(2, surname);
				ps.setString(3, username);
				ps.setInt(4, age);
				ps.setString(6, "client");
				
				
				BCryptPasswordEncoder pe = new BCryptPasswordEncoder();
				
				String hp = pe.encode(password);
				
				ps.setString(5, hp);
				
				ps.executeUpdate();

				result = true;
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			result = false;
		}
		
		return result;
	}	

}
