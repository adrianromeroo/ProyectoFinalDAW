package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.security.crypto.bcrypt.BCrypt;

import database.DBConnection;

public class LoginDAOImpl implements LoginDAO{
	
	final static Logger logger = Logger.getLogger(LoginDAOImpl.class);
	
	public boolean doLogin(String username, String password) {
		
		logger.info("doLogin method has been invoked [LoginDAOImpl.class]");
			
		Connection con = DBConnection.getConnecttion();
		
		boolean result = false;
		
		if(con != null && username != null && password != null) {
			String sql = "select username,password from user where username = ?";
			PreparedStatement ps;
			
			try {
				ps = (PreparedStatement) con.prepareStatement(sql);
				
				ps.setString(1, username);
				
				ResultSet rs = ps.executeQuery();
				
				String hashedPassword = "";
				
				while(rs.next()) {
					hashedPassword =  rs.getString("password");
				}
				
				
				if (checkPassword(password, hashedPassword)) {
					result = true;
				} 
				
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			result = false;
		}
		logger.info("getUsers method has retrieved [LoginDAOImpl.class]");
		return result;
		
	}

	@Override
	public boolean checkPassword(String password, String hashedPassword) {
		boolean result = false;
		
		if (BCrypt.checkpw(password, hashedPassword)) {
			result = true;
		} else {
			result = false;
		}
		return result;
	}

}
