package controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import dao.LoginDAOImpl;


@WebServlet("/login")
public class LoginServlet extends javax.servlet.http.HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private LoginDAOImpl loginDAO = new LoginDAOImpl();
	
	final static Logger logger = Logger.getLogger(LoginServlet.class);

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
			
		} catch (Exception e) {
			e.printStackTrace();
		}			
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		String 	urlLanding = "/WEB-INF/index.jsp";
		String 	urlLogin = "/login.jsp";
		
		logger.info("Client has invoked POST operation [LoginServlet.class]");
		
		
		try {
			if (loginDAO.doLogin(username, password)) {
				HttpSession session = request.getSession();
				session.setAttribute("username", username);
				
				Cookie loginCookie = new Cookie("username",username);
				loginCookie.setMaxAge(30*60); //setting cookie to expiry in 30 mins
				
				response.addCookie(loginCookie);
				
				getServletContext().getRequestDispatcher(urlLanding).forward(request, response);
			} else {
				//response.sendRedirect(urlLogin);
				RequestDispatcher rd = getServletContext().getRequestDispatcher(urlLogin);
                rd.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}	
		
		
	}

}
