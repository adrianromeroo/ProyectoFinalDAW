package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import dao.UserDAOImpl;

@WebServlet("/create")
public class CreateUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	final static Logger logger = Logger.getLogger(CreateUserServlet.class);
       
	private UserDAOImpl UserDAO = new UserDAOImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		logger.info("Client has invoked POST operation [CreateUserServlet.class]");
		
		String name = request.getParameter("name");
		String surname = request.getParameter("surname");
		String username = request.getParameter("username");
		int age = Integer.valueOf(request.getParameter("age"));
		String password = request.getParameter("password");
		
		
		UserDAO.createUser(name, surname, username, age, password);
		getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
	}

}
