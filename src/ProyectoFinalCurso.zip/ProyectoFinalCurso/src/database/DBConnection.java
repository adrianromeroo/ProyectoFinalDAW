package database;


import java.sql.Connection;



import java.sql.DriverManager;
import java.util.Properties;

import org.apache.log4j.Logger;

public class DBConnection {

	private static Connection connection = null;
	
	final static Logger logger = Logger.getLogger(DBConnection.class);
	
	public static Connection getConnecttion() {
		Properties prop = new Properties();
		try {
			if(connection == null  || connection.isClosed()) {
				prop.load(Thread.currentThread()
						.getContextClassLoader()
						.getResourceAsStream("configuration.properties"));
				
		        String classForname = prop.getProperty("db.classForName");
		        String url = prop.getProperty("db.URL") + "//" + prop.getProperty("db.host") + "/" + prop.getProperty("db.name");
		        String username = prop.getProperty("db.username");
		        String password = prop.getProperty("db.password");
				
				Class.forName(classForname);
				connection = DriverManager.getConnection(
						url,		
						username,	
						password);
				//System.out.println(url + " - username: " + username + " password: " + password);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return connection;					
	}

}